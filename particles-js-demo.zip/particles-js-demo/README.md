# Particles.js demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/batmiles/pen/jPVxpd](https://codepen.io/batmiles/pen/jPVxpd).

Backdrop for my personal website. Quick demo in low-contrast particles.js