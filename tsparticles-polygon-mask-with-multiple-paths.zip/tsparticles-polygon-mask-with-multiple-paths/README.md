# tsParticles polygon mask with multiple paths

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/MWaePMa](https://codepen.io/matteobruni/pen/MWaePMa).

tsParticles polygon mask with multiple paths, used G logo as sample, it has 4 svg paths