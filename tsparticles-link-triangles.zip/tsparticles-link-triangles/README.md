# tsParticles link triangles

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/WNQgXJZ](https://codepen.io/matteobruni/pen/WNQgXJZ).

tsParticles link triangles