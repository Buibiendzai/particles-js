# tsParticles chars

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/xxGdyjd](https://codepen.io/matteobruni/pen/xxGdyjd).

Made with tsParticles, a lightweight TypeScript library for creating particles